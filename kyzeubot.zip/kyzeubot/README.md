## Userbot
```
apt update && apt upgrade -y
```
```
git clone https://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@github.com/UbotPremium/mybot
```
```
cd mybot && screen -S mybot
```
```
apt install ffmpeg -y
```
```
bash installnode.sh
```
```
apt install python3.10-venv
```
```
python3 -m venv mybot && source mybot/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
screen -S mybot
```
```
python3 -m PyroUbot
```
```
---------- Menghidupan jika ubot mati -------------
```
```
cd mybot && screen -S mybot
```
```
python3 -m venv mybot && source mybot/bin/activate
```
```
screen -S mybot
```
```
python3 -m PyroUbot
```
